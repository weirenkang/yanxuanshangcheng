<template>
  <div class="sy">
      首页
  </div>
</template>

<script>
export default {
name:"sy"
}
</script>

<style>

</style>