<template>
  <div class="gwc">
      购物车
  </div>
</template>

<script>
export default {
name:"gwc"
}
</script>

<style>

</style>