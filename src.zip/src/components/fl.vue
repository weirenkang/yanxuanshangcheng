<template>
  <div class="fl">
      分类
  </div>
</template>

<script>
export default {
name:"fl"
}
</script>

<style>

</style>