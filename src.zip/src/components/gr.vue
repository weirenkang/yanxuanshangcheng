<template>
  <div class="gr">
      个人
  </div>
</template>

<script>
export default {
name:"gr"
}
</script>

<style>

</style>